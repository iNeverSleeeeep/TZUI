local #ViewName# = BaseClass()

function #ViewName#:Load(panel)
    self.panel = panel
    self.views = panel.views
end

function #ViewName#:Release()

end

function #ViewName#:Show()

end

function #ViewName#:Hide()

end

return #ViewName#