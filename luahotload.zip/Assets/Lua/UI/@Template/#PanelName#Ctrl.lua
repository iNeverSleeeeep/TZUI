local #PanelName#Ctrl = BaseClass()


return #PanelName#Ctrl