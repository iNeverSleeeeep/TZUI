local #ViewName# = require("UI.#PanelName#.Generated.#ViewName#")

-- 刷新全部显示
function #ViewName#:RefreshAll()

end

return #ViewName#