local #PanelName#Config = {}

--#PanelName#Config.#ViewName# = {}

--#PanelName#Config.#ViewName#.#WidgetName# = {}

return #PanelName#Config