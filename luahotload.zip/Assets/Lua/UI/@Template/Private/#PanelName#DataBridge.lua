local #PanelName#DataBridge = require("UI.#PanelName#.Generated.#PanelName#DataBridge")


return #PanelName#DataBridge