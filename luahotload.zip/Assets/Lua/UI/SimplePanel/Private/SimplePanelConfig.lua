local SimplePanelConfig = {}

--SimplePanelConfig.#ViewName# = {}

--SimplePanelConfig.#ViewName#.#WidgetName# = {}
CS.UnityEngine.Debug.Log(123355566)
return SimplePanelConfig