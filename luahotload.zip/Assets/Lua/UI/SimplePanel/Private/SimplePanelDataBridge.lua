local SimplePanelDataBridge = require("UI.SimplePanel.Generated.SimplePanelDataBridge")


return SimplePanelDataBridge