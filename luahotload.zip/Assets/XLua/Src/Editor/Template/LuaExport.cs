﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System;

public static class LuaExport
{
    public static List<Type> TZUITypes = new List<Type>
    {
        typeof(TZUI.UIBinder),
    };
}
